# Import libraries
from langgraph.graph import StateGraph, END  # LangGraph
from pydantic import BaseModel  # State schema validation and management
# Warnings
import warnings
warnings.filterwarnings("ignore")

# Suppress asyncio warnings
import asyncio
import sys
import logging

# Suppress specific asyncio and httpx warnings
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)
warnings.filterwarnings("ignore", category=RuntimeWarning, module="asyncio")

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

# Define the state of the CIO Agent
class CIOAgentState(BaseModel):
    user_query: str = ""  # user input from client (UI)
    selected_data_source: str = ""  # selected data source (vectordb/mem0)
    retrieved_documents: list = []  # final processed documents from RetrieveData
    retrieval_source: str = ""  # source of retrieval
    retrieval_count: int = 0  # number of final processed documents
    reranking_model: str = ""  # reranking model used
    merged_context: dict = {}  # merged context from Collator
    context_sources: list = []  # list of context sources used
    context_summary: str = ""  # summary of merged context
    confidence: str = ""  # confidence level of context
    context_ready: bool = False  # whether context is ready for next step
    generated_response: str = ""  # generated response from LLM
    response_model: str = ""  # model used for response generation
    prompt_used: str = ""  # prompt used for generation (for debugging)
    # Quality check fields
    retry_count: int = 0  # number of retries attempted
    quality_attempts: list = []  # list of quality check attempts
    current_quality_evaluation: dict = {}  # current quality evaluation
    quality_status: str = ""  # PASS or FAIL
    quality_score: int = 0  # quality score out of 100
    final_response: str = ""  # final approved response
    best_quality_score: int = 0  # best score from all attempts
    best_attempt_number: int = 0  # which attempt had the best score
    quality_check_complete: bool = False  # whether quality check is complete
    needs_retry: bool = False  # whether retry is needed
    retry_feedback: dict = {}  # feedback for retry attempts
    final_result: str = ""  # final processing result
    debug_info: dict = {}  # debug information from retrieve_data_node
    collator_debug_info: dict = {}  # debug information from collator_node

# Import agent nodes
def import_nodes():
    from nodes.cio_agent_node import cio_agent_node
    from nodes.data_source_selector_node import data_source_selector_node
    from nodes.retrieve_data_node import retrieve_data_node
    from nodes.collator_node import collator_node
    from nodes.response_generation_node import response_generation_node
    from nodes.quality_check_node import quality_check_node
    from nodes.retry_controller_node import retry_controller_node
    return {
        "cio_agent": cio_agent_node,
        "data_source_selector": data_source_selector_node,
        "retrieve_data": retrieve_data_node,
        "collator": collator_node,
        "response_generation": response_generation_node,
        "quality_check": quality_check_node,
        "retry_controller": retry_controller_node
    }

# Route after CIO agent processing
def route_after_cio_agent(state):
    # CIO Agent receives input from client (UI) and starts processing
    # Skip query embedding, go directly to data source selector
    return "data_source_selector"

# Route after data source selector
def route_after_data_source_selector(state):
    # Import the routing function
    from nodes.data_source_selector_node import route_after_data_source_selector
    return route_after_data_source_selector(state)

# Route after quality check
def route_after_quality_check(state):
    """Route after quality check - always go to retry controller for decision"""
    return "retry_controller"

# Route after retry controller
def route_after_retry_controller(state):
    """Route after retry controller - retry or end based on retry controller decision"""
    if state.needs_retry and not state.quality_check_complete:
        # Quality check failed, retry from retrieve_data to get different documents
        print(f"🔄 Retry Controller: Routing back to retrieve_data (Attempt {state.retry_count + 1}/3)")
        return "retrieve_data"
    else:
        # Quality check passed or max retries reached, end process
        print(f"✅ Retry Controller: Process complete, ending")
        return END

def build_cio_agent_graph():
    nodes = import_nodes()
    graph = StateGraph(CIOAgentState)

    # Add all nodes
    for name, func in nodes.items():
        graph.add_node(name, func)

    # Set entry point
    graph.set_entry_point("cio_agent")

    # Define flow
    graph.add_conditional_edges("cio_agent", route_after_cio_agent)
    graph.add_conditional_edges("data_source_selector", route_after_data_source_selector)
    graph.add_edge("retrieve_data", "collator")
    graph.add_edge("collator", "response_generation")
    graph.add_edge("response_generation", "quality_check")
    graph.add_conditional_edges("quality_check", route_after_quality_check)
    graph.add_conditional_edges("retry_controller", route_after_retry_controller)

    return graph.compile()

if __name__ == "__main__":
    print("\n Welcome to the CIO Agent System!")
    user_prompt = input("\nPlease enter your query (e.g., What are the latest trends in AI for enterprise?):\n\n")

    graph = build_cio_agent_graph()
    final_state = graph.invoke({"user_query": user_prompt})

    print("\n" + "="*80)
    print("✅ CIO AGENT PROCESSING COMPLETE")
    print("="*80)
    print("🔍 DEBUG: Final state processing starting...")
    
    # Query Information
    print(f"\n🔍 QUERY: {final_state.get('user_query', '')}")
    print(f"📊 Data Source Selected: {final_state.get('selected_data_source', '')}")
    print(f"📊 Retrieval Source: {final_state.get('retrieval_source', '')}")
    print(f"📊 Reranking Model: {final_state.get('reranking_model', 'N/A')}")
    
    # Retrieval pipeline results are now shown during execution
    # Collator results are now shown during execution
    
    # Show final processed documents summary
    final_docs = final_state.get('retrieved_documents', [])
    if final_docs:
        print(f"\n🎯 FINAL PROCESSED DOCUMENTS SUMMARY:")
        for i, doc in enumerate(final_docs, 1):
            print(f"   {i}. {doc['id']} (Cohere: {doc['score']:.3f}, Original: {doc['original_score']:.3f}) - {doc['metadata'].get('category', 'N/A')}")
    
    # Show quality check summary
    quality_status = final_state.get('quality_status', 'N/A')
    quality_score = final_state.get('quality_score', 0)
    total_attempts = len(final_state.get('quality_attempts', []))
    best_score = final_state.get('best_quality_score', quality_score)
    
    if quality_status != 'N/A':
        print(f"\n🔍 QUALITY CHECK SUMMARY:")
        print(f"📊 Final Status: {quality_status}")
        print(f"📊 Final Score: {quality_score}/100")
        print(f"📊 Best Score: {best_score}/100")
        print(f"📊 Total Attempts: {total_attempts}")
    
    # Show final approved response
    final_response = final_state.get('final_response', '')
    if final_response:
        print(f"\n🎯 FINAL APPROVED RESPONSE:")
        print("-" * 80)
        print(final_response)
        print("-" * 80)
    
    # Show any errors
    final_result = final_state.get('final_result', '')
    if final_result:
        print(f"\n❌ FINAL RESULT: {final_result}")
    
    print("\n" + "="*80)
