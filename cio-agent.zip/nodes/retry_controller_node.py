"""
Retry Controller Node - Manages retry logic based on quality check results
"""

import logging

logger = logging.getLogger(__name__)

def retry_controller_node(state):
    """
    Retry Controller Node - Decides whether to retry or complete based on quality check
    
    Args:
        state: Current state containing quality evaluation results
        
    Returns:
        Updated state with retry decision
    """
    try:
        print(f"\n🔄 RETRY CONTROLLER NODE: Analyzing quality results...")
        logger.info("Retry Controller Node: Starting retry decision process")
        
        # Get current state information
        quality_status = getattr(state, 'quality_status', 'FAIL')
        quality_score = getattr(state, 'quality_score', 0)
        current_attempt = getattr(state, 'retry_count', 0) + 1
        max_retries = 3
        
        # Initialize retry count if not exists
        if not hasattr(state, 'retry_count'):
            state.retry_count = 0
        
        print(f"🔄 Retry Controller Debug - Current Attempt: {current_attempt}/{max_retries}")
        print(f"🔄 Retry Controller Debug - Quality Status: {quality_status}")
        print(f"🔄 Retry Controller Debug - Quality Score: {quality_score}/100")
        print(f"🔄 Retry Controller Debug - Retry Count: {state.retry_count}")
        print(f"🔄 Retry Controller Debug - Quality Complete: {getattr(state, 'quality_check_complete', False)}")
        
        # Decision logic
        if quality_status == "PASS":
            # Quality check passed - complete the process
            state.needs_retry = False
            state.quality_check_complete = True
            state.final_response = state.generated_response
            
            print(f"✅ Retry Controller Decision: QUALITY CHECK PASSED")
            print(f"📊 Final Score: {quality_score}/100")
            print(f"📊 Completed in {current_attempt} attempt(s)")
            
        elif current_attempt >= max_retries:
            # Max retries reached - complete with best attempt
            state.needs_retry = False
            state.quality_check_complete = True
            
            # Use the best attempt as final response
            best_score = getattr(state, 'best_quality_score', quality_score)
            best_attempt = getattr(state, 'best_attempt_number', current_attempt)
            
            # Find the best response from attempts
            quality_attempts = getattr(state, 'quality_attempts', [])
            best_response = state.generated_response  # Default to current
            
            for attempt in quality_attempts:
                if attempt['attempt_number'] == best_attempt:
                    # We would need to store responses per attempt to implement this fully
                    # For now, use the current response
                    break
            
            state.final_response = best_response
            
            print(f"⚠️  Retry Controller Decision: MAX RETRIES REACHED")
            print(f"📊 Using Best Attempt: {best_attempt} (Score: {best_score}/100)")
            print(f"📊 Total Attempts: {current_attempt}")
            
        else:
            # Quality check failed and retries available - retry
            state.needs_retry = True
            state.quality_check_complete = False
            state.retry_count = current_attempt
            
            # Prepare feedback for retry
            current_evaluation = getattr(state, 'current_quality_evaluation', {})
            improvement_suggestions = current_evaluation.get('improvement_suggestions', [])
            weaknesses = current_evaluation.get('weaknesses', [])
            
            retry_feedback = {
                "previous_score": quality_score,
                "previous_status": quality_status,
                "improvement_suggestions": improvement_suggestions,
                "weaknesses": weaknesses,
                "attempt_number": current_attempt,
                "reasoning": current_evaluation.get('reasoning', 'Quality check failed')
            }
            
            state.retry_feedback = retry_feedback
            
            print(f"🔄 Retry Controller Decision: RETRY REQUIRED")
            print(f"📊 Previous Score: {quality_score}/100")
            print(f"📊 Attempts Remaining: {max_retries - current_attempt}")
            print(f"🔄 Strategy: Will retry from RETRIEVAL to get different documents")
            
            if improvement_suggestions:
                print(f"📊 Key Improvements Needed:")
                for i, suggestion in enumerate(improvement_suggestions[:3], 1):
                    print(f"   {i}. {suggestion}")
        
        print("-" * 60)
        
        logger.info(f"Retry Controller Node: Decision complete - Retry: {state.needs_retry}, Complete: {state.quality_check_complete}")
        return state
        
    except Exception as e:
        logger.error(f"Retry Controller Node error: {str(e)}")
        # Default to completion on error
        state.needs_retry = False
        state.quality_check_complete = True
        state.final_response = getattr(state, 'generated_response', '')
        state.final_result = f"Error in retry controller: {str(e)}"
        return state


