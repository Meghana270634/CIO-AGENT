"""
Collator Node - Merges contexts from different sources and provides structured context
"""

import logging
import os
from typing import Dict, List, Any

logger = logging.getLogger(__name__)

class Collator:
    """
    Collator class that merges tools, RAG, and memory context
    """
    
    def __init__(self):
        self.tools_context = {}  # Context from tools (currently empty)
        self.rag_context = {}    # Context from RAG/retrieval systems
        self.memory_context = {} # Context from memory systems (currently empty)
    
    def merge_contexts(self, tools: Dict[str, Any], rag: Dict[str, Any], memory: Dict[str, Any]) -> Dict[str, Any]:
        """
        Merges tools, RAG, and memory context into a unified context with deduplication
        
        Args:
            tools: Context from tools (currently empty for VectorDB-only system)
            rag: Context from RAG/retrieval systems (VectorDB results)
            memory: Context from memory systems (currently empty)
            
        Returns:
            Dict: Merged context ready for LLM response generation
        """
        logger.info("Collator: Starting context merging process with deduplication")
        
        # Store contexts
        self.tools_context = tools
        self.rag_context = rag
        self.memory_context = memory
        
        # Extract key information
        query = rag.get('query', '')
        retrieved_documents = rag.get('retrieved_documents', [])
        retrieval_source = rag.get('retrieval_source', '')
        
        # Apply deduplication
        deduplicated_documents = self._deduplicate_documents(retrieved_documents)
        
        # Create document summary
        document_summary = self._create_document_summary(deduplicated_documents)
        
        # Determine confidence level
        confidence = self._determine_confidence(deduplicated_documents)
        
        # Count total documents (after deduplication)
        total_documents = len(deduplicated_documents)
        
        # Create context sources list
        context_sources = []
        if deduplicated_documents:
            context_sources.append(retrieval_source)
        if tools:
            context_sources.append("tools")
        if memory:
            context_sources.append("memory")
        
        # Create merged context
        merged_context = {
            "query": query,
            "context_sources": context_sources,
            "total_documents": total_documents,
            "documents": deduplicated_documents,
            "summary": document_summary,
            "confidence": confidence,
            "context_ready": True,
            "tools_context": tools,
            "rag_context": rag,
            "memory_context": memory
        }
        
        logger.info(f"Collator: Successfully merged context with {total_documents} documents from {len(context_sources)} sources (after deduplication)")
        return merged_context
    
    def _deduplicate_documents(self, documents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Remove duplicate documents based on ID and content similarity
        
        Args:
            documents: List of documents to deduplicate
            
        Returns:
            List: Deduplicated documents
        """
        if not documents:
            return documents
        
        logger.info(f"Collator: Starting deduplication of {len(documents)} documents")
        
        # Method 1: Remove exact ID duplicates (keep highest score)
        id_seen = {}
        for doc in documents:
            doc_id = doc.get('id', '')
            if doc_id not in id_seen:
                id_seen[doc_id] = doc
            else:
                # Keep document with higher score
                current_score = doc.get('score', 0)
                existing_score = id_seen[doc_id].get('score', 0)
                if current_score > existing_score:
                    id_seen[doc_id] = doc
        
        # Convert back to list
        unique_by_id = list(id_seen.values())
        
        # Method 2: Remove content duplicates based on semantic similarity
        deduplicated = []
        for doc in unique_by_id:
            is_duplicate = False
            doc_text = self._get_document_text(doc)
            doc_embedding = self._get_document_embedding(doc_text)
            
            for existing_doc in deduplicated:
                existing_text = self._get_document_text(existing_doc)
                existing_embedding = self._get_document_embedding(existing_text)
                
                # Calculate semantic similarity
                similarity = self._calculate_cosine_similarity(doc_embedding, existing_embedding)
                similarity_threshold = 0.85  # Adjust threshold as needed
                
                if similarity > similarity_threshold:
                    # Keep document with higher score
                    doc_score = doc.get('score', 0)
                    existing_score = existing_doc.get('score', 0)
                    
                    if doc_score > existing_score:
                        # Replace existing document with higher scoring one
                        deduplicated.remove(existing_doc)
                        deduplicated.append(doc)
                        logger.info(f"Collator: Replaced document {existing_doc.get('id')} with {doc.get('id')} (similarity: {similarity:.3f})")
                    else:
                        logger.info(f"Collator: Skipped duplicate document {doc.get('id')} (similarity: {similarity:.3f})")
                    is_duplicate = True
                    break
            
            if not is_duplicate:
                deduplicated.append(doc)
        
        # Sort by score (highest first)
        deduplicated.sort(key=lambda x: x.get('score', 0), reverse=True)
        
        logger.info(f"Collator: Deduplication complete - {len(documents)} → {len(deduplicated)} documents")
        return deduplicated
    
    def _get_document_text(self, doc: Dict[str, Any]) -> str:
        """
        Extract text content from document for semantic analysis
        
        Args:
            doc: Document dictionary
            
        Returns:
            str: Document text content
        """
        # First try to get actual text from metadata
        text = doc.get('metadata', {}).get('text', '')
        
        # If no text, create descriptive text from metadata
        if not text:
            category = doc.get('metadata', {}).get('category', '')
            source = doc.get('metadata', {}).get('source', '')
            year = doc.get('metadata', {}).get('year', '')
            text = f"This is a {category} document from {source} published in {year}. It covers topics related to {category} and provides insights on {category} technologies and applications."
        
        return text
    
    def _get_document_embedding(self, text: str) -> List[float]:
        """
        Generate embedding for document text using Azure OpenAI
        
        Args:
            text: Document text to embed
            
        Returns:
            List[float]: Document embedding vector
        """
        try:
            import asyncio
            from openai import AsyncAzureOpenAI
            
            # Get Azure OpenAI credentials
            api_key = os.getenv("AZURE_OPENAI_API_KEY")
            azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
            api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
            
            # Generate embedding using context manager
            async def get_embedding():
                from openai import AsyncAzureOpenAI
                async with AsyncAzureOpenAI(
                    api_key=api_key,
                    azure_endpoint=azure_endpoint,
                    api_version=api_version
                ) as client:
                    response = await client.embeddings.create(
                        model="text-embedding-ada-002",
                        input=text
                    )
                    return response
            
            response = asyncio.run(get_embedding())
            
            return response.data[0].embedding
            
        except Exception as e:
            logger.error(f"Collator: Error generating embedding: {str(e)}")
            # Return zero vector as fallback
            return [0.0] * 1536
    
    def _calculate_cosine_similarity(self, embedding1: List[float], embedding2: List[float]) -> float:
        """
        Calculate cosine similarity between two embeddings
        
        Args:
            embedding1: First embedding vector
            embedding2: Second embedding vector
            
        Returns:
            float: Cosine similarity score (0.0 to 1.0)
        """
        try:
            import numpy as np
            
            # Convert to numpy arrays
            vec1 = np.array(embedding1)
            vec2 = np.array(embedding2)
            
            # Calculate cosine similarity
            dot_product = np.dot(vec1, vec2)
            norm1 = np.linalg.norm(vec1)
            norm2 = np.linalg.norm(vec2)
            
            if norm1 == 0 or norm2 == 0:
                return 0.0
            
            similarity = dot_product / (norm1 * norm2)
            return float(similarity)
            
        except Exception as e:
            logger.error(f"Collator: Error calculating cosine similarity: {str(e)}")
            return 0.0
    
    def _create_document_summary(self, documents: List[Dict[str, Any]]) -> str:
        """
        Create a summary of retrieved documents
        
        Args:
            documents: List of retrieved documents
            
        Returns:
            str: Summary of documents
        """
        if not documents:
            return "No relevant documents found"
        
        if len(documents) == 1:
            doc = documents[0]
            category = doc.get('metadata', {}).get('category', 'Unknown')
            score = doc.get('score', 0)
            return f"Found 1 relevant document about {category} (relevance: {score:.3f})"
        
        # Multiple documents - create detailed summary
        categories = []
        scores = []
        
        for doc in documents:
            category = doc.get('metadata', {}).get('category', 'Unknown')
            score = doc.get('score', 0)
            categories.append(category)
            scores.append(score)
        
        # Find most relevant document
        max_score = max(scores)
        max_index = scores.index(max_score)
        primary_category = categories[max_index]
        
        if len(set(categories)) == 1:
            # All documents are same category
            return f"Found {len(documents)} relevant documents about {primary_category} (highest relevance: {max_score:.3f})"
        else:
            # Multiple categories
            unique_categories = list(set(categories))
            if len(unique_categories) == 2:
                return f"Found {len(documents)} relevant documents: {primary_category} (highest relevance: {max_score:.3f}) and {unique_categories[1]}"
            else:
                return f"Found {len(documents)} relevant documents: {primary_category} (highest relevance: {max_score:.3f}) and {len(unique_categories)-1} other topics"
    
    def _determine_confidence(self, documents: List[Dict[str, Any]]) -> str:
        """
        Determine confidence level based on document quality and scores
        
        Args:
            documents: List of retrieved documents
            
        Returns:
            str: Confidence level (low, medium, high)
        """
        if not documents:
            return "low"
        
        if len(documents) == 1:
            score = documents[0].get('score', 0)
            if score > 0.05:
                return "high"
            elif score > 0.01:
                return "medium"
            else:
                return "low"
        
        # Multiple documents
        scores = [doc.get('score', 0) for doc in documents]
        max_score = max(scores)
        avg_score = sum(scores) / len(scores)
        
        if max_score > 0.05 and avg_score > 0.01:
            return "high"
        elif max_score > 0.01 and avg_score > 0.005:
            return "medium"
        else:
            return "low"

def collator_node(state):
    """
    Collator Node - Merges contexts and provides structured context for LLM
    
    Args:
        state: Current state containing retrieved documents and query
        
    Returns:
        Updated state with merged context
    """
    try:
        print(f"\n🔄 COLLATOR NODE: Starting...")
        logger.info("Collator Node: Starting context merging")
        
        # Get data from state
        user_query = state.user_query
        retrieved_documents = state.retrieved_documents
        retrieval_source = state.retrieval_source
        
        print(f"🔍 Collator Debug - User Query: {user_query}")
        print(f"🔍 Collator Debug - Retrieved Documents: {len(retrieved_documents)}")
        print(f"🔍 Collator Debug - Retrieval Source: {retrieval_source}")
        
        # Prepare RAG context
        rag_context = {
            "query": user_query,
            "retrieved_documents": retrieved_documents,
            "retrieval_source": retrieval_source,
            "retrieval_count": len(retrieved_documents)
        }
        
        # Prepare tools context (currently empty)
        tools_context = {}
        
        # Prepare memory context (currently empty)
        memory_context = {}
        
        # Initialize Collator
        collator = Collator()
        
        # Merge contexts
        merged_context = collator.merge_contexts(
            tools=tools_context,
            rag=rag_context,
            memory=memory_context
        )
        
        # Update state with merged context and deduplicated documents
        state.merged_context = merged_context
        state.context_sources = merged_context["context_sources"]
        state.context_summary = merged_context["summary"]
        state.confidence = merged_context["confidence"]
        state.context_ready = merged_context["context_ready"]
        
        # Store original document count before deduplication
        original_doc_count = len(retrieved_documents)
        
        # Update retrieved_documents with deduplicated documents from merged context
        deduplicated_documents = merged_context["documents"]
        state.retrieved_documents = deduplicated_documents
        state.retrieval_count = len(deduplicated_documents)
        
        # Store collator results for later display
        collator_debug_info = {
            "context_sources": merged_context['context_sources'],
            "documents_before_dedup": original_doc_count,
            "documents_after_dedup": merged_context['total_documents'],
            "confidence": merged_context['confidence'],
            "summary": merged_context['summary'],
            "context_ready": merged_context['context_ready']
        }
        
        # Set the debug info on the state
        state.collator_debug_info = collator_debug_info
        
        print(f"✅ COLLATOR NODE: Completed successfully")
        logger.info(f"Collator Node: Successfully merged context with {len(merged_context['context_sources'])} sources")
        return state
        
    except Exception as e:
        logger.error(f"Collator Node error: {str(e)}")
        state.final_result = f"Error in context merging: {str(e)}"
        return state
