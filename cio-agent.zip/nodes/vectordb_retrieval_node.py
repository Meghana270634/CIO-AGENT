"""
VectorDB Retrieval Node - Performs dense vector search using Pinecone
"""

import logging
import os
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

def get_pinecone_client():
    """Get Pinecone client"""
    try:
        from pinecone import Pinecone
        api_key = os.getenv("PINECONE_API_KEY")
        if not api_key:
            raise ValueError("PINECONE_API_KEY not found in environment variables")
        
        pc = Pinecone(api_key=api_key)
        return pc
    except ImportError:
        raise ImportError("Pinecone library not installed. Please install with: pip install pinecone-client")

def vectordb_retrieval_node(state):
    """
    VectorDB Retrieval Node - Performs dense vector search using cosine similarity
    
    Args:
        state: Current state containing user query
        
    Returns:
        Updated state with retrieval results
    """
    try:
        logger.info("VectorDB Retrieval: Starting vector search")
        
        # Get user query
        user_query = state.user_query
        if not user_query:
            raise ValueError("No user query found in state")
        
        # Generate embeddings for the query on-the-fly
        import asyncio
        from openai import AsyncAzureOpenAI
        
        # Get Azure OpenAI credentials
        api_key = os.getenv("AZURE_OPENAI_API_KEY")
        azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
        
        # Initialize Azure OpenAI client
        client = AsyncAzureOpenAI(
            api_key=api_key,
            azure_endpoint=azure_endpoint,
            api_version=api_version
        )
        
        # Generate embeddings for the query
        response = asyncio.run(client.embeddings.create(
            model="text-embedding-ada-002",
            input=user_query
        ))
        
        query_embeddings = response.data[0].embedding
        
        # Get Pinecone client
        pc = get_pinecone_client()
        
        # Get index name from environment or use default
        index_name = os.getenv("PINECONE_INDEX_NAME", "membrane-poc-dotproduct")
        
        # Connect to index
        index = pc.Index(index_name)
        
        # Perform vector search using cosine similarity
        search_results = index.query(
            vector=query_embeddings,
            top_k=10,  # Get more results to filter
            include_metadata=True
        )
        
        # Filter results by similarity threshold
        similarity_threshold = 0.8  # Only return highly relevant results
        filtered_results = [match for match in search_results.matches if match.score >= similarity_threshold]
        
        # Extract results from filtered matches
        retrieved_documents = []
        for match in filtered_results:
            retrieved_documents.append({
                "id": match.id,
                "score": match.score,
                "metadata": match.metadata
            })
        
        # Update state with retrieval results
        state.retrieved_documents = retrieved_documents
        state.retrieval_source = "vectordb"
        state.retrieval_count = len(retrieved_documents)
        
        # Display retrieved documents
        print(f"\n🔍 VectorDB Search Results for: '{user_query}'")
        print(f"Found {len(retrieved_documents)} relevant documents:")
        print("-" * 60)
        
        for i, doc in enumerate(retrieved_documents, 1):
            print(f"\n📄 Document {i}:")
            print(f"   ID: {doc['id']}")
            print(f"   Score: {doc['score']:.3f}")
            print(f"   Category: {doc['metadata'].get('category', 'N/A')}")
            print(f"   Source: {doc['metadata'].get('source', 'N/A')}")
            print(f"   Year: {doc['metadata'].get('year', 'N/A')}")
        
        print("-" * 60)
        
        logger.info(f"VectorDB Retrieval: Retrieved {len(retrieved_documents)} documents")
        return state
        
    except Exception as e:
        logger.error(f"VectorDB Retrieval error: {str(e)}")
        state.final_result = f"Error in vector retrieval: {str(e)}"
        return state
