"""
Query Embedding Node - Converts user query to embeddings using Azure OpenAI
"""

import asyncio
import os
from openai import AsyncAzureOpenAI
from dotenv import load_dotenv

load_dotenv()

def query_embedding_node(state):
    """
    Node that converts user query into embeddings using Azure OpenAI
    
    Args:
        state: Current state containing user query
        
    Returns:
        Updated state with embeddings
    """
    # Get Azure OpenAI credentials for embeddings
    api_key = os.getenv("AZURE_OPENAI_API_KEY")  # Kaaraone Membrane POC
    azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")  # Kaaraone Membrane POC
    
    # Initialize Azure OpenAI client
    client = AsyncAzureOpenAI(
        api_key=api_key,
        azure_endpoint=azure_endpoint,
    )
    
    # Get embedding model from state or environment
    embedding_model = state.embedding_model or os.getenv("AZURE_OPENAI_EMBEDDING_MODEL", "text-embedding-ada-002")
    
    # Generate embeddings
    response = asyncio.run(client.embeddings.create(
        model=embedding_model,
        input=state.user_query
    ))
    
    # Get embeddings result
    embeddings = response.data[0].embedding
    
    # Show embedding results
    print(f"\n🔹 Query Embedding Results:")
    print(f"Query: '{state.user_query}'")
    print(f"Model: {embedding_model}")
    print(f"Dimensions: {len(embeddings)}")
    print(f"First 10 values: [{', '.join([f'{val:.3f}' for val in embeddings[:10]])}, ...]")
    print(f"Full embeddings: [{', '.join([f'{val:.3f}' for val in embeddings])}]")
    
    # Update state with embeddings
    state.query_embeddings = embeddings
    
    return state


