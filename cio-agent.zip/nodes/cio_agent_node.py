"""
CIO Agent Node - Main orchestrator node for processing user queries
"""

from typing import Dict, Any
import logging

logger = logging.getLogger(__name__)


def cio_agent_node(state):
    """
    CIO Agent - Main entry point that receives input from client (UI)
    and orchestrates the query processing flow
    
    Args:
        state: Current state containing user query from client (UI)
        
    Returns:
        Updated state ready for first processing step (query embeddings)
    """
    try:
        logger.info(f"CIO Agent: Received input from client (UI) - '{state.user_query}'")
        
        # CIO Agent receives input from client (UI) and validates it
        if not state.user_query or not isinstance(state.user_query, str):
            logger.error("Invalid user query: must be a non-empty string")
            state.final_result = "Error: Invalid user query: must be a non-empty string"
            return state
        
        # CIO Agent prepares the query for processing
        # First step will be query embeddings
        logger.info("CIO Agent: Query validated, ready for first processing step (query embeddings)")
        
        return state
        
    except Exception as e:
        logger.error(f"Unexpected error in CIO Agent: {str(e)}")
        state.final_result = f"Error: Unexpected system error - {str(e)}"
        return state


