"""
Response Generation Node - Constructs prompts and generates responses using Azure OpenAI
"""

import logging
import os
import asyncio
from typing import Dict, List, Any
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

class ResponseGenerator:
    """
    Response Generator class that handles prompt construction and LLM response generation
    """
    
    def __init__(self):
        self.azure_client = None
        
    def get_azure_client(self):
        """Get Azure OpenAI client"""
        if self.azure_client is None:
            try:
                from openai import AsyncAzureOpenAI
                
                # Get Azure OpenAI credentials
                api_key = os.getenv("AZURE_OPENAI_CHAT_KEY")
                azure_endpoint = os.getenv("AZURE_OPENAI_CHAT_ENDPOINT")
                api_version = os.getenv("AZURE_OPENAI_CHAT_API_VERSION")
                
                if not api_key or not azure_endpoint:
                    raise ValueError("Azure OpenAI credentials not found in environment variables")
                
                # Debug: Print configuration (without exposing API key)
                print(f"🔧 Azure OpenAI Configuration:")
                print(f"   Endpoint: {azure_endpoint}")
                print(f"   API Version: {api_version}")
                print(f"   API Key: {'*' * len(api_key) if api_key else 'Not set'}")
                
                self.azure_client = AsyncAzureOpenAI(
                    api_key=api_key,
                    azure_endpoint=azure_endpoint,
                    api_version=api_version
                )
            except ImportError:
                raise ImportError("OpenAI library not installed. Please install with: pip install openai")
        return self.azure_client
    
    def construct_prompt(self, user_query: str, context: Dict[str, Any]) -> str:
        """
        Construct a comprehensive prompt with context and query
        
        Args:
            user_query: The user's original query
            context: Context information from collator (documents, sources, etc.)
            
        Returns:
            str: Constructed prompt for the LLM
        """
        logger.info("ResponseGenerator: Constructing prompt with context")
        
        # Extract context information
        context_sources = context.get('context_sources', [])
        documents = context.get('documents', [])
        confidence = context.get('confidence', 'unknown')
        summary = context.get('summary', 'No context available')
        
        # Build context section
        context_section = self._build_context_section(documents, context_sources, confidence, summary)
        
        # Construct the full prompt
        prompt = f"""You are a CIO (Chief Information Officer) AI assistant specialized in enterprise technology, digital transformation, and strategic IT decision-making.

## CONTEXT INFORMATION
{context_section}

## USER QUERY
{user_query}

## RESPONSE GUIDELINES
1. Provide a SHORT, CONCISE response based ONLY on the context provided
2. Keep response under 500 words maximum
3. Focus on key insights directly from the documents
4. Use bullet points for clarity and brevity
5. Do NOT add general knowledge or recommendations beyond the context
6. Maintain a professional, executive-level tone
7. Structure: Brief summary + key points from documents only

## EXECUTIVE RESPONSE (KEEP CONCISE - MAX 500 WORDS)"""
        
        logger.info(f"ResponseGenerator: Constructed prompt with {len(documents)} documents from {len(context_sources)} sources")
        return prompt
    
    def _build_context_section(self, documents: List[Dict], context_sources: List[str], confidence: str, summary: str) -> str:
        """
        Build the context section of the prompt
        
        Args:
            documents: List of retrieved documents
            context_sources: List of context sources used
            confidence: Confidence level of the context
            summary: Summary of the context
            
        Returns:
            str: Formatted context section
        """
        context_parts = []
        
        # Add context summary
        context_parts.append(f"### Context Summary: {summary}")
        context_parts.append(f"### Confidence Level: {confidence}")
        context_parts.append(f"### Sources: {', '.join(context_sources)}")
        context_parts.append("")
        
        # Add document details
        if documents:
            context_parts.append("### RELEVANT DOCUMENTS:")
            for i, doc in enumerate(documents, 1):
                doc_id = doc.get('id', f'Document {i}')
                category = doc.get('metadata', {}).get('category', 'Unknown')
                source = doc.get('metadata', {}).get('source', 'Unknown')
                year = doc.get('metadata', {}).get('year', 'Unknown')
                score = doc.get('score', 0)
                
                # Get document text
                doc_text = doc.get('metadata', {}).get('text', '')
                if not doc_text:
                    # Create descriptive text if not available
                    doc_text = f"This is a {category} document from {source} published in {year}. It covers topics related to {category} and provides insights on {category} technologies and applications."
                
                context_parts.append(f"\n#### Document {i} ({doc_id})")
                context_parts.append(f"- **Category:** {category}")
                context_parts.append(f"- **Source:** {source}")
                context_parts.append(f"- **Year:** {year}")
                context_parts.append(f"- **Relevance Score:** {score:.3f}")
                context_parts.append(f"- **Content:** {doc_text}")
        else:
            context_parts.append("No relevant documents found in the knowledge base.")
        
        return "\n".join(context_parts)
    
    async def generate_response(self, prompt: str, model: str = None) -> str:
        """
        Generate response using Azure OpenAI
        
        Args:
            prompt: The constructed prompt
            model: The model to use for generation
            
        Returns:
            str: Generated response from the LLM
        """
        # Get model from environment variable if not provided
        if model is None:
            model = os.getenv("AZURE_OPENAI_CHAT_MODEL", "gpt-4.1-nano-membrane-poc")
        
        logger.info(f"ResponseGenerator: Generating response using {model}")
        print(f"🔧 Using Model: {model}")
        
        try:
            # Use context manager for proper cleanup
            from openai import AsyncAzureOpenAI
            
            # Get Azure OpenAI credentials (same as quality check)
            api_key = os.getenv("AZURE_OPENAI_CHAT_KEY")
            azure_endpoint = os.getenv("AZURE_OPENAI_CHAT_ENDPOINT")
            api_version = os.getenv("AZURE_OPENAI_CHAT_API_VERSION")
            
            async with AsyncAzureOpenAI(
                api_key=api_key,
                azure_endpoint=azure_endpoint,
                api_version=api_version
            ) as client:
                # Generate response
                response = await client.chat.completions.create(
                model=model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a CIO AI assistant. Provide SHORT, CONCISE responses based only on the provided context. Maximum 500 words."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                max_tokens=800,  # Reduced from 2000 to encourage shorter responses
                temperature=0.3,  # Lower temperature for more focused responses
                top_p=0.8
            )
            
            generated_response = response.choices[0].message.content
            logger.info(f"ResponseGenerator: Successfully generated response ({len(generated_response)} characters)")
            return generated_response
            
        except Exception as e:
            logger.error(f"ResponseGenerator: Error generating response: {str(e)}")
            return f"Error generating response: {str(e)}"

def response_generation_node(state):
    """
    Response Generation Node - Constructs prompts and generates responses
    
    Args:
        state: Current state containing user query and merged context
        
    Returns:
        Updated state with generated response
    """
    try:
        print(f"\n🚀 RESPONSE GENERATION NODE: Starting...")
        logger.info("Response Generation Node: Starting response generation")
        
        # Get data from state
        user_query = state.user_query
        merged_context = state.merged_context
        retrieved_documents = state.retrieved_documents
        
        print(f"🔍 Debug - User Query: {user_query}")
        print(f"🔍 Debug - Merged Context Keys: {list(merged_context.keys()) if merged_context else 'None'}")
        print(f"🔍 Debug - Retrieved Documents: {len(retrieved_documents) if retrieved_documents else 0}")
        
        if not user_query:
            raise ValueError("No user query found in state")
        
        if not merged_context:
            raise ValueError("No merged context found in state")
        
        # Check if any relevant documents were found
        if not retrieved_documents or len(retrieved_documents) == 0:
            print(f"⚠️ RESPONSE GENERATION: No relevant documents found for query")
            print(f"📊 Query: {user_query}")
            print(f"📊 Retrieved Documents: {len(retrieved_documents) if retrieved_documents else 0}")
            print(f"🚫 RESPONSE GENERATION SKIPPED - No relevant context available")
            
            # Set empty response and skip generation
            state.generated_response = ""
            state.response_model = "N/A - No documents found"
            state.prompt_used = "N/A - No documents found"
            state.final_result = f"No relevant documents found for query: {user_query}"
            
            return state
        
        # Check document relevance scores - require high quality documents
        high_quality_docs = [doc for doc in retrieved_documents if doc.get('score', 0) >= 0.5]
        
        if len(high_quality_docs) == 0:
            print(f"⚠️ RESPONSE GENERATION: Documents found but relevance too low")
            print(f"📊 Query: {user_query}")
            print(f"📊 Documents Found: {len(retrieved_documents)}")
            print(f"📊 High Quality Documents (≥0.5): {len(high_quality_docs)}")
            print(f"🚫 RESPONSE GENERATION SKIPPED - Document relevance too low")
            
            # Set empty response and skip generation
            state.generated_response = ""
            state.response_model = "N/A - Low relevance documents"
            state.prompt_used = "N/A - Low relevance documents"
            state.final_result = f"Documents found but relevance too low for query: {user_query}"
            
            return state
        
        # Initialize Response Generator
        response_generator = ResponseGenerator()
        
        # Construct prompt with context
        prompt = response_generator.construct_prompt(user_query, merged_context)
        
        # Generate response using Azure OpenAI
        generated_response = asyncio.run(response_generator.generate_response(prompt))
        
        # Update state with generated response
        state.generated_response = generated_response
        state.response_model = os.getenv("AZURE_OPENAI_CHAT_MODEL", "gpt-4.1-nano-membrane-poc")
        state.prompt_used = prompt[:500] + "..." if len(prompt) > 500 else prompt  # Store truncated prompt for debugging
        
        # Display response generation results
        print(f"\n🤖 RESPONSE GENERATION RESULTS:")
        print(f"📊 Model Used: {state.response_model}")
        print(f"📊 Response Length: {len(generated_response)} characters")
        print(f"📊 Context Sources: {', '.join(merged_context.get('context_sources', []))}")
        print(f"📊 Documents Used: {len(merged_context.get('documents', []))}")
        print(f"📊 Confidence: {merged_context.get('confidence', 'N/A')}")
        
        # Display prompt construction debug info
        print(f"\n🔧 PROMPT CONSTRUCTION DEBUG:")
        print(f"📊 Prompt Length: {len(prompt)} characters")
        print(f"📊 Context Documents: {len(merged_context.get('documents', []))}")
        print(f"📊 Context Sources: {', '.join(merged_context.get('context_sources', []))}")
        
        print(f"\n📝 CONSTRUCTED PROMPT:")
        print("-" * 80)
        print(prompt)
        print("-" * 80)
        
        print(f"\n📝 GENERATED RESPONSE:")
        print("-" * 80)
        print(generated_response)
        print("-" * 80)
        
        print(f"✅ RESPONSE GENERATION NODE: Completed successfully")
        logger.info("Response Generation Node: Successfully generated response")
        return state
        
    except Exception as e:
        logger.error(f"Response Generation Node error: {str(e)}")
        state.final_result = f"Error in response generation: {str(e)}"
        return state
