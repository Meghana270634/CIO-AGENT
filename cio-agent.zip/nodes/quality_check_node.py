"""
Quality Check Node - Evaluates generated responses using LLM for quality validation
"""

import logging
import os
import asyncio
from typing import Dict, List, Any
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

class QualityChecker:
    """
    Quality Checker class that evaluates generated responses using LLM
    """
    
    def __init__(self):
        self.azure_client = None
        
    def get_azure_client(self):
        """Get Azure OpenAI client"""
        if self.azure_client is None:
            try:
                from openai import AzureOpenAI
                
                # Get Azure OpenAI credentials
                api_key = os.getenv("AZURE_OPENAI_CHAT_KEY")
                azure_endpoint = os.getenv("AZURE_OPENAI_CHAT_ENDPOINT")
                api_version = os.getenv("AZURE_OPENAI_CHAT_API_VERSION")
                
                if not api_key or not azure_endpoint:
                    raise ValueError("Azure OpenAI credentials not found in environment variables")
                
                self.azure_client = AzureOpenAI(
                    api_key=api_key,
                    azure_endpoint=azure_endpoint,
                    api_version="2024-02-15-preview"
                )
            except ImportError:
                raise ImportError("OpenAI library not installed. Please install with: pip install openai")
        return self.azure_client
    
    def construct_quality_check_prompt(self, user_query: str, generated_response: str, context: Dict[str, Any], raw_documents: List[Dict] = None) -> str:
        """
        Construct a prompt for quality checking the generated response
        
        Args:
            user_query: The original user query
            generated_response: The response to evaluate
            context: Context information used for generation
            raw_documents: Raw documents retrieved from VectorDB (for relevance checking)
            
        Returns:
            str: Constructed quality check prompt
        """
        logger.info("QualityChecker: Constructing quality evaluation prompt")
        
        # Extract context information
        context_sources = context.get('context_sources', [])
        documents = context.get('documents', [])
        confidence = context.get('confidence', 'unknown')
        
        prompt = f"""You are a Quality Assurance AI specialized in evaluating CIO-level enterprise responses for accuracy, completeness, and professional quality.

## EVALUATION TASK
Evaluate the quality of the generated response based on the following criteria:

## ORIGINAL USER QUERY
{user_query}

## CONTEXT USED FOR GENERATION
- **Sources**: {', '.join(context_sources)}
- **Documents Available**: {len(documents)}
- **Context Confidence**: {confidence}

## RAW DOCUMENTS RETRIEVED FROM VECTORDB
{self._format_raw_documents(raw_documents) if raw_documents else "No raw documents provided"}

## GENERATED RESPONSE TO EVALUATE
{generated_response}

## QUALITY EVALUATION CRITERIA
Evaluate the response on a scale of 1-100 based on these criteria:

### 1. Query-Response Relevance (30 points) - CRITICAL
- Does the response directly address the user's query topic?
- Are the retrieved documents relevant to the query?
- If documents are off-topic, does the response acknowledge this appropriately?

### 2. Accuracy & Factual Correctness (25 points)
- Are the facts, figures, and claims accurate?
- Is the information consistent with the context provided?
- Are there any factual errors or misrepresentations?

### 3. Completeness & Coverage (20 points)
- Does the response address all parts of the user query?
- Are all key aspects covered comprehensively?
- Is any critical information missing?

### 4. Professional Quality & Tone (15 points)
- Is the tone appropriate for a CIO-level executive audience?
- Is the language professional and clear?
- Is the structure logical and well-organized?

### 5. Context Utilization (10 points)
- Does the response effectively use the provided context?
- Are specific details from the context incorporated appropriately?
- If context is irrelevant, does the response handle this gracefully?

## EVALUATION OUTPUT FORMAT
Provide your evaluation in the following JSON format:

{{
    "overall_score": [score out of 100],
    "status": "[PASS or FAIL]",
    "criteria_scores": {{
        "query_relevance": [score out of 30],
        "accuracy": [score out of 25],
        "completeness": [score out of 20],
        "professional_quality": [score out of 15],
        "context_utilization": [score out of 10]
    }},
    "strengths": [
        "List of response strengths"
    ],
    "weaknesses": [
        "List of response weaknesses"
    ],
    "improvement_suggestions": [
        "Specific suggestions for improvement"
    ],
    "pass_threshold_met": [true/false],
    "reasoning": "Brief explanation of the overall assessment"
}}

## PASS/FAIL CRITERIA
- **PASS**: Overall score >= 70 AND no critical factual errors AND addresses main query components
- **FAIL**: Overall score < 70 OR contains critical factual errors OR fails to address key query components

## QUALITY EVALUATION"""
        
        logger.info(f"QualityChecker: Constructed quality check prompt ({len(prompt)} characters)")
        return prompt
    
    def _format_raw_documents(self, raw_documents: List[Dict]) -> str:
        """
        Format raw documents for quality check evaluation
        
        Args:
            raw_documents: List of raw documents from VectorDB
            
        Returns:
            str: Formatted raw documents section
        """
        if not raw_documents:
            return "No raw documents available"
        
        formatted_docs = []
        formatted_docs.append(f"**Total Raw Documents Retrieved**: {len(raw_documents)}")
        formatted_docs.append("")
        
        for i, doc in enumerate(raw_documents, 1):
            doc_id = doc.get('id', f'Document {i}')
            score = doc.get('score', 0)
            metadata = doc.get('metadata', {})
            
            # Get actual document text
            doc_text = metadata.get('text', '')
            if not doc_text:
                # Try other possible text fields
                doc_text = metadata.get('content', '')
                if not doc_text:
                    doc_text = f"No text content available for document {doc_id}"
            
            formatted_docs.append(f"**Raw Document {i} ({doc_id})**")
            formatted_docs.append(f"- VectorDB Similarity Score: {score:.3f}")
            formatted_docs.append(f"- Metadata: {metadata}")
            formatted_docs.append(f"- Content Preview: {doc_text[:200]}...")
            formatted_docs.append("")
        
        return "\n".join(formatted_docs)
    
    def evaluate_response_quality(self, prompt: str, model: str = None) -> Dict[str, Any]:
        """
        Evaluate response quality using Azure OpenAI
        
        Args:
            prompt: The constructed quality check prompt
            model: The model to use for evaluation
            
        Returns:
            Dict: Quality evaluation results
        """
        # Get model from environment variable if not provided
        if model is None:
            model = os.getenv("AZURE_OPENAI_CHAT_MODEL", "gpt-4.1-nano-membrane-poc")
        
        logger.info(f"QualityChecker: Evaluating response quality using {model}")
        
        try:
            client = self.get_azure_client()
            
            # Generate quality evaluation
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a Quality Assurance AI specialized in evaluating enterprise-level responses. Always respond with valid JSON format."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                max_tokens=1500,
                temperature=0.1,  # Low temperature for consistent evaluation
                top_p=0.9
            )
            
            evaluation_text = response.choices[0].message.content
            logger.info(f"QualityChecker: Received evaluation ({len(evaluation_text)} characters)")
            
            # Try to parse JSON response
            try:
                import json
                evaluation_result = json.loads(evaluation_text)
                logger.info(f"QualityChecker: Successfully parsed JSON evaluation")
                return evaluation_result
            except json.JSONDecodeError:
                logger.error("QualityChecker: Failed to parse JSON, returning text evaluation")
                return {
                    "overall_score": 50,
                    "status": "FAIL",
                    "reasoning": "Failed to parse quality evaluation response",
                    "raw_response": evaluation_text
                }
            
        except Exception as e:
            logger.error(f"QualityChecker: Error evaluating response: {str(e)}")
            return {
                "overall_score": 0,
                "status": "FAIL",
                "reasoning": f"Error in quality evaluation: {str(e)}",
                "error": str(e)
            }

def quality_check_node(state):
    """
    Quality Check Node - Evaluates generated response quality using LLM
    
    Args:
        state: Current state containing generated response and context
        
    Returns:
        Updated state with quality evaluation results
    """
    try:
        print(f"\n🔍 QUALITY CHECK NODE: Starting evaluation...")
        logger.info("Quality Check Node: Starting response quality evaluation")
        
        # Get data from state
        user_query = state.user_query
        generated_response = state.generated_response
        merged_context = state.merged_context
        raw_documents = getattr(state, 'debug_info', {}).get('raw_results', [])
        current_attempt = getattr(state, 'retry_count', 0) + 1
        
        # Check if response generation was skipped due to no documents
        if not generated_response:
            print(f"🔍 QUALITY CHECK: No response to evaluate (response generation was skipped)")
            print(f"📊 Reason: No relevant documents found for query")
            print(f"✅ QUALITY CHECK SKIPPED - No response to evaluate")
            
            # Set appropriate state for skipped evaluation
            state.quality_status = "SKIPPED"
            state.quality_score = 0
            state.quality_check_complete = True
            state.needs_retry = False
            state.final_response = f"No relevant documents found in knowledge base for query: {user_query}"
            
            return state
        
        print(f"🔍 Quality Check Debug - Attempt: {current_attempt}")
        print(f"🔍 Quality Check Debug - Response Length: {len(generated_response)} characters")
        print(f"🔍 Quality Check Debug - Context Available: {bool(merged_context)}")
        print(f"🔍 Quality Check Debug - Raw Documents: {len(raw_documents)}")
        
        # Initialize Quality Checker
        quality_checker = QualityChecker()
        
        # Construct quality check prompt with raw documents
        quality_prompt = quality_checker.construct_quality_check_prompt(
            user_query, generated_response, merged_context, raw_documents
        )
        
        # Evaluate response quality using Azure OpenAI
        evaluation_result = quality_checker.evaluate_response_quality(quality_prompt)
        
        # Update state with quality evaluation results
        state.current_quality_evaluation = evaluation_result
        state.quality_status = evaluation_result.get('status', 'FAIL')
        state.quality_score = evaluation_result.get('overall_score', 0)
        
        # Initialize quality attempts list if not exists
        if not hasattr(state, 'quality_attempts'):
            state.quality_attempts = []
        
        # Store this attempt
        attempt_data = {
            "attempt_number": current_attempt,
            "quality_score": state.quality_score,
            "status": state.quality_status,
            "evaluation": evaluation_result,
            "response_length": len(generated_response)
        }
        state.quality_attempts.append(attempt_data)
        
        # Track best attempt
        if not hasattr(state, 'best_quality_score') or state.quality_score > state.best_quality_score:
            state.best_quality_score = state.quality_score
            state.best_attempt_number = current_attempt
        
        # Display quality check results
        print(f"\n🔍 QUALITY CHECK RESULTS:")
        print(f"📊 Attempt: {current_attempt}")
        print(f"📊 Overall Score: {state.quality_score}/100")
        print(f"📊 Status: {state.quality_status}")
        print(f"📊 Best Score So Far: {getattr(state, 'best_quality_score', state.quality_score)}")
        
        # Show detailed scores if available
        criteria_scores = evaluation_result.get('criteria_scores', {})
        if criteria_scores:
            print(f"📊 Detailed Scores:")
            print(f"   - Query Relevance: {criteria_scores.get('query_relevance', 'N/A')}/30")
            print(f"   - Accuracy: {criteria_scores.get('accuracy', 'N/A')}/25")
            print(f"   - Completeness: {criteria_scores.get('completeness', 'N/A')}/20")
            print(f"   - Professional Quality: {criteria_scores.get('professional_quality', 'N/A')}/15")
            print(f"   - Context Utilization: {criteria_scores.get('context_utilization', 'N/A')}/10")
        
        # Show reasoning
        reasoning = evaluation_result.get('reasoning', 'No reasoning provided')
        print(f"📊 Reasoning: {reasoning}")
        
        # Show improvement suggestions if status is FAIL
        if state.quality_status == "FAIL":
            suggestions = evaluation_result.get('improvement_suggestions', [])
            if suggestions:
                print(f"📊 Improvement Suggestions:")
                for i, suggestion in enumerate(suggestions, 1):
                    print(f"   {i}. {suggestion}")
        
        print("-" * 60)
        
        logger.info(f"Quality Check Node: Completed evaluation - Score: {state.quality_score}, Status: {state.quality_status}")
        return state
        
    except Exception as e:
        logger.error(f"Quality Check Node error: {str(e)}")
        # Set default failure state
        state.quality_status = "FAIL"
        state.quality_score = 0
        state.current_quality_evaluation = {"error": str(e)}
        state.final_result = f"Error in quality check: {str(e)}"
        return state
