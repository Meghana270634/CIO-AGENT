"""
RetrieveData Node - Complete retrieval pipeline with VectorDB + Cohere Reranking + Filtering
"""

import logging
import os
import asyncio
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

class RetrieveData:
    """
    RetrieveData class that provides processed docs through:
    1. VectorDB retrieval
    2. Cohere reranking
    3. Score threshold filtering
    4. Top N selection
    """
    
    def __init__(self, top_k=10, rerank_threshold=0.7):
        self.top_k = top_k  # Number of top results to retrieve
        self.cohere_client = None  # Cohere client for reranking
        self.rerank_threshold = rerank_threshold  # Threshold for filtering after reranking
        
    def get_pinecone_client(self):
        """Get Pinecone client"""
        try:
            from pinecone import Pinecone
            api_key = os.getenv("PINECONE_API_KEY")
            if not api_key:
                raise ValueError("PINECONE_API_KEY not found in environment variables")
            
            pc = Pinecone(api_key=api_key)
            return pc
        except ImportError:
            raise ImportError("Pinecone library not installed. Please install with: pip install pinecone-client")

    def get_cohere_client(self):
        """Get Cohere client"""
        if self.cohere_client is None:
            try:
                import cohere
                api_key = os.getenv("COHERE_API_KEY")
                if not api_key:
                    raise ValueError("COHERE_API_KEY not found in environment variables")
                
                self.cohere_client = cohere.Client(api_key=api_key)
            except ImportError:
                raise ImportError("Cohere library not installed. Please install with: pip install cohere")
        return self.cohere_client

    def generate_query_embeddings(self, user_query):
        """Generate embeddings for the user query using Azure OpenAI"""
        # Get Azure OpenAI credentials
        api_key = os.getenv("AZURE_OPENAI_API_KEY")
        azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
        
        # Generate embeddings for the query using context manager
        async def get_embeddings():
            from openai import AsyncAzureOpenAI
            async with AsyncAzureOpenAI(
                api_key=api_key,
                azure_endpoint=azure_endpoint,
                api_version=api_version
            ) as client:
                response = await client.embeddings.create(
                    model="text-embedding-ada-002",
                    input=user_query
                )
                return response
        
        response = asyncio.run(get_embeddings())
        
        return response.data[0].embedding

    def get_raw_results(self, user_query):
        """Step 1: Get raw results from VectorDB"""
        logger.info("RetrieveData: Getting raw results from VectorDB")
        
        # Generate query embeddings
        query_embeddings = self.generate_query_embeddings(user_query)
        
        # Get Pinecone client
        pc = self.get_pinecone_client()
        index_name = os.getenv("PINECONE_INDEX_NAME", "membrane-poc-dotproduct")
        index = pc.Index(index_name)
        
        # Perform vector search
        search_results = index.query(
            vector=query_embeddings,
            top_k=self.top_k,
            include_metadata=True
        )
        
        # Convert to list of documents
        raw_results = []
        for match in search_results.matches:
            raw_results.append({
                "id": match.id,
                "score": match.score,
                "metadata": match.metadata
            })
        
        logger.info(f"RetrieveData: Retrieved {len(raw_results)} raw documents")
        return raw_results

    def apply_reranking(self, docs, user_query):
        """Step 2: Apply Cohere reranking to documents"""
        logger.info("RetrieveData: Applying Cohere reranking")
        
        if not docs:
            return docs
        
        try:
            # Get Cohere client
            co = self.get_cohere_client()
            
            # Prepare documents for reranking
            documents_for_rerank = []
            for doc in docs:
                text = doc['metadata'].get('text', '')
                if not text:
                    # Create more descriptive text for Cohere
                    category = doc['metadata'].get('category', '')
                    source = doc['metadata'].get('source', '')
                    year = doc['metadata'].get('year', '')
                    text = f"This is a {category} document from {source} published in {year}. It covers topics related to {category} and provides insights on {category} technologies and applications."
                documents_for_rerank.append(text)
            
            # Perform Cohere reranking
            rerank_response = co.rerank(
                model="rerank-english-v3.0",
                query=user_query,
                documents=documents_for_rerank,
                top_n=len(documents_for_rerank),
                return_documents=False
            )
            
            # Map reranked results back to original documents
            reranked_docs = []
            for i, result in enumerate(rerank_response.results):
                original_doc = docs[i]
                reranked_doc = {
                    "id": original_doc["id"],
                    "score": result.relevance_score,  # New Cohere score
                    "original_score": original_doc["score"],  # Original VectorDB score
                    "metadata": original_doc["metadata"],
                    "rerank_position": i + 1
                }
                reranked_docs.append(reranked_doc)
            
            # Sort by new relevance score (highest first)
            reranked_docs.sort(key=lambda x: x["score"], reverse=True)
            
            logger.info(f"RetrieveData: Reranked {len(reranked_docs)} documents")
            return reranked_docs
            
        except Exception as e:
            logger.error(f"RetrieveData: Reranking failed: {str(e)}")
            # Fallback: return original documents with consistent structure
            fallback_docs = []
            for doc in docs:
                fallback_doc = {
                    "id": doc["id"],
                    "score": doc["score"],
                    "original_score": doc["score"],
                    "metadata": doc["metadata"],
                    "rerank_position": len(fallback_docs) + 1
                }
                fallback_docs.append(fallback_doc)
            return fallback_docs

    def filter_by_score_threshold(self, docs, threshold):
        """Step 3: Filter documents by score threshold"""
        logger.info(f"RetrieveData: Filtering by score threshold {threshold}")
        
        filtered_docs = [doc for doc in docs if doc["score"] >= threshold]
        logger.info(f"RetrieveData: Filtered to {len(filtered_docs)} documents above threshold")
        return filtered_docs

    def select_top_n(self, docs, n):
        """Step 4: Select top N documents"""
        logger.info(f"RetrieveData: Selecting top {n} documents")
        
        top_docs = docs[:n]
        logger.info(f"RetrieveData: Selected {len(top_docs)} top documents")
        return top_docs

    def process(self, raw_results, user_query):
        """
        Main processing method that orchestrates the complete pipeline:
        1. Apply reranking
        2. Filter by score threshold
        3. Select top N
        """
        logger.info("RetrieveData: Starting complete processing pipeline")
        
        # Step 1: Apply reranking
        reranked_docs = self.apply_reranking(raw_results, user_query)
        
        # Step 2: Filter by score threshold
        filtered_docs = self.filter_by_score_threshold(reranked_docs, self.rerank_threshold)
        
        # Step 3: Select top N
        final_docs = self.select_top_n(filtered_docs, self.top_k)
        
        logger.info(f"RetrieveData: Processing complete - {len(final_docs)} final documents")
        return final_docs

def retrieve_data_node(state):
    """
    RetrieveData Node - Complete retrieval pipeline with VectorDB + Cohere + Filtering
    
    Args:
        state: Current state containing user query
        
    Returns:
        Updated state with processed retrieval results
    """
    try:
        # Check if this is a retry attempt
        retry_count = getattr(state, 'retry_count', 0)
        if retry_count > 0:
            print(f"\n🔄 RETRIEVE DATA NODE: Retry attempt {retry_count + 1}/3")
            retry_feedback = getattr(state, 'retry_feedback', {})
            if retry_feedback:
                print(f"📊 Previous Quality Score: {retry_feedback.get('previous_score', 'N/A')}/100")
                print(f"📊 Retry Reason: {retry_feedback.get('reasoning', 'Quality check failed')}")
        else:
            print(f"\n🔍 RETRIEVE DATA NODE: Initial attempt")
        
        logger.info("RetrieveData Node: Starting complete retrieval pipeline")
        
        # Get user query
        user_query = state.user_query
        if not user_query:
            raise ValueError("No user query found in state")
        
        # Initialize RetrieveData instance with retry-aware parameters
        if retry_count > 0:
            # On retry, try different parameters to get better results
            if retry_count == 1:
                # First retry: Lower rerank threshold to get more documents
                retriever = RetrieveData(top_k=8, rerank_threshold=0.05)
                print(f"🔄 Retry Strategy 1: Increased top_k to 8, lowered threshold to 0.05")
            else:
                # Second retry: Even more aggressive search
                retriever = RetrieveData(top_k=10, rerank_threshold=0.01)
                print(f"🔄 Retry Strategy 2: Increased top_k to 10, lowered threshold to 0.01")
        else:
            # Initial attempt: Standard parameters
            retriever = RetrieveData(top_k=5, rerank_threshold=0.1)
            print(f"🔍 Initial Strategy: top_k=5, rerank_threshold=0.1")
        
        # Step 1: Get raw results from VectorDB
        raw_results = retriever.get_raw_results(user_query)
        
        # Step 2-4: Process through reranking, filtering, and top N selection
        processed_docs = retriever.process(raw_results, user_query)
        
        # Update state with processed results
        state.retrieved_documents = processed_docs
        state.retrieval_source = "vectordb"
        state.retrieval_count = len(processed_docs)
        state.reranking_model = "rerank-english-v3.0"
        
        # Display retrieval pipeline results immediately
        print(f"\n🔍 RETRIEVAL PIPELINE RESULTS:")
        
        # Show raw VectorDB results
        print(f"\n📊 Raw VectorDB Results: {len(raw_results)} documents")
        if raw_results:
            for i, doc in enumerate(raw_results, 1):
                print(f"   {i}. {doc['id']} (VectorDB Score: {doc['score']:.3f}) - {doc['metadata'].get('category', 'N/A')}")
        else:
            print("   ⚠️  No documents retrieved from VectorDB")
        
        # Show processed documents after reranking
        print(f"\n📊 Final Processed Documents: {len(processed_docs)} documents")
        if processed_docs:
            for i, doc in enumerate(processed_docs, 1):
                print(f"   {i}. {doc['id']} (Cohere: {doc['score']:.3f}, Original: {doc['original_score']:.3f}) - {doc['metadata'].get('category', 'N/A')}")
        else:
            print(f"   ⚠️  No documents passed the reranking threshold ({retriever.rerank_threshold})")
        
        print("-" * 60)
        
        # Store debug info for final summary
        state.debug_info = {
            "raw_results": raw_results,
            "processed_docs": processed_docs,
            "rerank_threshold": retriever.rerank_threshold
        }
        
        logger.info(f"RetrieveData Node: Successfully processed {len(processed_docs)} documents")
        return state
        
    except Exception as e:
        logger.error(f"RetrieveData Node error: {str(e)}")
        state.final_result = f"Error in retrieval pipeline: {str(e)}"
        return state
