"""
Data Source Selector Node - Selects between VectorDB and Mem0 data sources
"""

import logging

logger = logging.getLogger(__name__)

def data_source_selector_node(state):
    """
    Data Source Selector Node - Selects the appropriate data source
    
    Args:
        state: Current state containing query embeddings
        
    Returns:
        Updated state with selected data source
    """
    try:
        logger.info("Data Source Selector: Selecting data source")
        
        # For now, always select VectorDB (Pinecone)
        # In future, this can be made conditional based on query type, embeddings, etc.
        selected_source = "vectordb"
        
        # Update state with selected data source
        state.selected_data_source = selected_source
        
        logger.info(f"Data Source Selector: Selected {selected_source}")
        return state
        
    except Exception as e:
        logger.error(f"Data Source Selector error: {str(e)}")
        state.final_result = f"Error in data source selection: {str(e)}"
        return state

def route_after_data_source_selector(state):
    """
    Route after data source selector based on selected source
    
    Args:
        state: Current state with selected data source
        
    Returns:
        str: Next node to execute
    """
    selected_source = getattr(state, "selected_data_source", "vectordb")
    
    if selected_source == "vectordb":
        return "retrieve_data"  # Updated to use new RetrieveData node
    elif selected_source == "mem0":
        return "mem0_retrieval"  # Placeholder for future Mem0 integration
    else:
        # Default to vectordb
        return "retrieve_data"  # Updated to use new RetrieveData node
