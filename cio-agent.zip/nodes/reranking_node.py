"""
Reranking Node - Uses Cohere to rerank VectorDB results for better relevance
"""

import logging
import os
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

def get_cohere_client():
    """Get Cohere client"""
    try:
        import cohere
        api_key = os.getenv("COHERE_API_KEY")
        if not api_key:
            raise ValueError("COHERE_API_KEY not found in environment variables")
        
        co = cohere.Client(api_key=api_key)
        return co
    except ImportError:
        raise ImportError("Cohere library not installed. Please install with: pip install cohere")

def reranking_node(state):
    """
    Reranking Node - Uses Cohere to rerank VectorDB results for better relevance
    
    Args:
        state: Current state containing retrieved documents from VectorDB
        
    Returns:
        Updated state with reranked documents
    """
    try:
        logger.info("Reranking: Starting Cohere reranking process")
        
        # Get retrieved documents from VectorDB
        retrieved_docs = state.retrieved_documents
        if not retrieved_docs:
            logger.warning("No documents to rerank from VectorDB")
            state.reranked_documents = []
            state.reranking_model = "none"
            state.reranking_count = 0
            return state
        
        # Get user query for reranking context
        user_query = state.user_query
        if not user_query:
            logger.warning("No user query found for reranking context")
            # Convert to consistent structure
            fallback_documents = []
            for doc in retrieved_docs:
                fallback_doc = {
                    "id": doc["id"],
                    "score": doc["score"],
                    "original_score": doc["score"],
                    "metadata": doc["metadata"],
                    "rerank_position": len(fallback_documents) + 1
                }
                fallback_documents.append(fallback_doc)
            state.reranked_documents = fallback_documents
            state.reranking_model = "none"
            state.reranking_count = len(fallback_documents)
            return state
        
        # Get Cohere client
        co = get_cohere_client()
        
        # Prepare documents for reranking
        # Cohere expects list of strings (document text)
        documents_for_rerank = []
        for doc in retrieved_docs:
            # Extract text from metadata or use a combination of fields
            text = doc['metadata'].get('text', '')
            if not text:
                # Fallback: combine available metadata fields
                text = f"Category: {doc['metadata'].get('category', '')} | Source: {doc['metadata'].get('source', '')}"
            documents_for_rerank.append(text)
        
        # Perform Cohere reranking
        print(f"🔍 Calling Cohere API with {len(documents_for_rerank)} documents...")
        print(f"Query: '{user_query}'")
        print(f"Documents: {documents_for_rerank}")
        
        rerank_response = co.rerank(
            model="rerank-english-v3.0",  # Cohere's latest reranking model
            query=user_query,
            documents=documents_for_rerank,
            top_n=len(documents_for_rerank),  # Rerank all documents
            return_documents=False  # We'll use the original documents with new scores
        )
        
        print(f"✅ Cohere API Response received: {len(rerank_response.results)} results")
        
        # Map reranked results back to original documents
        reranked_documents = []
        for i, result in enumerate(rerank_response.results):
            # Find the original document by index
            original_doc = retrieved_docs[i]
            
            # Create reranked document with new score
            reranked_doc = {
                "id": original_doc["id"],
                "score": result.relevance_score,  # New Cohere relevance score
                "original_score": original_doc["score"],  # Keep original VectorDB score
                "metadata": original_doc["metadata"],
                "rerank_position": i + 1  # Position after reranking
            }
            reranked_documents.append(reranked_doc)
        
        # Sort by new relevance score (highest first)
        reranked_documents.sort(key=lambda x: x["score"], reverse=True)
        
        # Update state with reranked results
        state.reranked_documents = reranked_documents
        state.reranking_model = "rerank-english-v3.0"
        state.reranking_count = len(reranked_documents)
        
        # Display reranking results
        print(f"\n🔄 Cohere Reranking Results for: '{user_query}'")
        print(f"Reranked {len(reranked_documents)} documents using Cohere:")
        print(f"Cohere API Response: {len(rerank_response.results)} results")
        print("-" * 70)
        
        for i, doc in enumerate(reranked_documents, 1):
            print(f"\n📄 Reranked Document {i}:")
            print(f"   ID: {doc['id']}")
            print(f"   Cohere Score: {doc['score']:.3f}")
            print(f"   Original Score: {doc['original_score']:.3f}")
            print(f"   Category: {doc['metadata'].get('category', 'N/A')}")
            print(f"   Source: {doc['metadata'].get('source', 'N/A')}")
            print(f"   Year: {doc['metadata'].get('year', 'N/A')}")
        
        print("-" * 70)
        
        logger.info(f"Reranking: Successfully reranked {len(reranked_documents)} documents")
        return state
        
    except Exception as e:
        logger.error(f"Reranking error: {str(e)}")
        # Fallback: return original documents if reranking fails
        # Ensure fallback documents have the same structure as reranked documents
        fallback_documents = []
        for doc in state.retrieved_documents:
            fallback_doc = {
                "id": doc["id"],
                "score": doc["score"],  # Use original score as both scores
                "original_score": doc["score"],
                "metadata": doc["metadata"],
                "rerank_position": len(fallback_documents) + 1
            }
            fallback_documents.append(fallback_doc)
        
        state.reranked_documents = fallback_documents
        state.reranking_model = "fallback"
        state.reranking_count = len(fallback_documents)
        return state
