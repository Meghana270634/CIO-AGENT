"""
Check what's in Pinecone index
"""

import os
from dotenv import load_dotenv
from pinecone import Pinecone

load_dotenv()

def check_pinecone_data():
    """Check what data is in Pinecone"""
    try:
        # Initialize Pinecone
        pc = Pinecone(api_key=os.getenv("PINECONE_API_KEY"))
        
        # Get index
        index_name = "cio-agent-index"
        index = pc.Index(index_name)
        
        # Get index stats
        stats = index.describe_index_stats()
        print(f"📊 Index Stats for '{index_name}':")
        print(f"   Total vectors: {stats.total_vector_count}")
        print(f"   Dimension: {stats.dimension}")
        print(f"   Index fullness: {stats.index_fullness}")
        
        # If no vectors, that's the problem
        if stats.total_vector_count == 0:
            print("❌ No vectors found in index!")
            print("   You need to run: python upload_dummy_data.py")
            return False
        
        # Get some sample vectors
        print(f"\n🔍 Sample vectors in index:")
        sample_results = index.query(
            vector=[0.1] * 1536,  # Dummy vector
            top_k=5,
            include_metadata=True
        )
        
        for i, match in enumerate(sample_results.matches, 1):
            print(f"   {i}. ID: {match.id}, Score: {match.score:.3f}")
            if match.metadata:
                print(f"      Metadata: {match.metadata}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error checking Pinecone: {str(e)}")
        return False

if __name__ == "__main__":
    print("🔍 Checking Pinecone Data...")
    check_pinecone_data()


