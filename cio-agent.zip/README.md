# CIO Agent LangGraph System

A sophisticated AI agent system built with LangGraph that processes user queries through embedding generation using Azure OpenAI services.

## 🏗️ Architecture

The system follows a modular LangGraph architecture with the following structure:

```
CIO Agent/
├── state.py                    # Graph state schema definition
├── nodes/                      # Individual processing nodes
│   ├── cio_agent_node.py      # Main orchestrator node
│   └── query_embedding_node.py # Embedding generation node
├── graphs/                     # Main graph definitions
│   └── cio_agent_graph.py     # CIO Agent LangGraph
├── tools/                      # External tools and services
│   └── azure_openai_embedding.py # Azure OpenAI integration
├── utils/                      # Reusable helpers
│   └── helpers.py             # Configuration, logging, utilities
├── main_graph.py              # Main entry point
├── config.json                # Configuration file
└── requirements.txt           # Dependencies
```

## 🔄 Graph Flow

```
User Query → CIO Agent Node → Query Embedding Node → Finalize Result → Output
```

### Node Details:

1. **CIO Agent Node** (`cio_agent_node.py`)
   - Main orchestrator that processes user queries
   - Validates and preprocesses input
   - Determines flow control

2. **Query Embedding Node** (`query_embedding_node.py`)
   - Converts processed queries to embeddings
   - Uses Azure OpenAI embedding services
   - Handles error recovery and retries

3. **Finalize Result Node** (`query_embedding_node.py`)
   - Formats final output
   - Adds metadata and processing information

## 🚀 Setup

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure Azure OpenAI
- Copy `config_example.env` to `.env`
- Fill in your Azure OpenAI credentials:
  ```env
  AZURE_OPENAI_API_KEY=your_api_key_here
  AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
  ```

### 3. Run the System
```bash
python main_graph.py
```

## 💻 Usage

### Basic Usage
```python
from graphs.cio_agent_graph import CIOAgentGraph
import asyncio

async def main():
    # Initialize the graph
    cio_agent = CIOAgentGraph()
    
    # Process a query
    result = await cio_agent.process_query("Your query here")
    print(result)

asyncio.run(main())
```

### Synchronous Usage
```python
from graphs.cio_agent_graph import CIOAgentGraph

# Initialize the graph
cio_agent = CIOAgentGraph()

# Process a query synchronously
result = cio_agent.process_query_sync("Your query here")
print(result)
```

### With Configuration
```python
config = {
    "embedding_model": "text-embedding-3-large",
    "max_retries": 5
}

result = await cio_agent.process_query("Your query", config)
```

## 🔧 Configuration

The system uses `config.json` for configuration:

```json
{
  "embedding_model": "text-embedding-ada-002",
  "max_retries": 3,
  "batch_size": 100,
  "log_level": "INFO",
  "azure_openai": {
    "api_version": "2024-02-15-preview"
  }
}
```

## 📊 State Schema

The graph uses a typed state schema defined in `state.py`:

```python
class CIOAgentState(TypedDict):
    user_query: str
    processed_query: Optional[str]
    query_embeddings: Optional[List[float]]
    embedding_model: Optional[str]
    final_result: Optional[Dict[str, Any]]
    status: str
    error_message: Optional[str]
    processing_steps: List[str]
    config: Optional[Dict[str, Any]]
```

## 🛠️ Features

- ✅ **LangGraph Integration** - Built with LangGraph for robust agent workflows
- ✅ **Async/Await Support** - High-performance async processing
- ✅ **Modular Architecture** - Clean separation of concerns
- ✅ **Error Handling** - Comprehensive error recovery and logging
- ✅ **Configuration Management** - Flexible configuration system
- ✅ **Azure OpenAI Integration** - Full Azure OpenAI embedding support
- ✅ **State Management** - Typed state schema with validation
- ✅ **Batch Processing** - Support for batch embedding generation
- ✅ **Logging** - Detailed logging and monitoring
- ✅ **Extensible** - Easy to add new nodes and functionality

## 🔍 Graph Information

You can inspect the graph structure:

```python
cio_agent = CIOAgentGraph()
graph_info = cio_agent.get_graph_info()
print(graph_info)
```

## 🧪 Testing

The system includes comprehensive error handling and validation:

- Query validation before processing
- Azure OpenAI connection testing
- Retry logic for failed requests
- Detailed error reporting

## 📝 Environment Variables

- `AZURE_OPENAI_API_KEY` - Your Azure OpenAI API key
- `AZURE_OPENAI_ENDPOINT` - Your Azure OpenAI endpoint URL
- `AZURE_OPENAI_API_VERSION` - API version (optional)

## 🔄 Extending the System

To add new functionality:

1. **Add new nodes** in the `nodes/` folder
2. **Update the graph** in `graphs/cio_agent_graph.py`
3. **Extend the state schema** in `state.py`
4. **Add new tools** in the `tools/` folder

## 📋 Requirements

- Python 3.8+
- Azure OpenAI service access
- Required packages listed in `requirements.txt`

## 🤝 Contributing

This system is designed to be modular and extensible. Feel free to add new nodes, tools, or functionality as needed.