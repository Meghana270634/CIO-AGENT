<!-- # Azure OpenAI Credentials Reference

## 🔑 **Embedding Service (Kaaraone Memebrane POC)**
- **Purpose:** Generate embeddings for queries
- **Endpoint:** `https://kaaraone-memebrane-poc-resource.services.ai.azure.com/`
- **Key:** `Cd4qp1wPu12GaW5XvtMHOi6VJCIHF56a3KTnj4cXSewGYsEpwqx2JQQJ99BIACHYHv6XJ3w3AAAAACOGw7nj`
- **Model:** `text-embedding-ada-002`
- **Usage:** Query embedding node

## 🔑 **Chat Service (Aura India)**
- **Purpose:** Chat completions and text generation
- **Endpoint:** `https://aura-india.cognitiveservices.azure.com/`
- **Key:** `2bgrZ8mkv9q0mENXaLLJM4FxFVczDAp1MSPLcGDRlRnmJkzyZSsTJQQJ99BEAC77bzfXJ3w3AAAAACOG774n`
- **Model:** `gpt-4.1-nano-AMC`
- **Usage:** Future chat completion features

## 📝 **Environment Variables:**
```env
# Embedding Service
AZURE_OPENAI_API_KEY=Cd4qp1wPu12GaW5XvtMHOi6VJCIHF56a3KTnj4cXSewGYsEpwqx2JQQJ99BIACHYHv6XJ3w3AAAAACOGw7nj
AZURE_OPENAI_ENDPOINT=https://kaaraone-memebrane-poc-resource.services.ai.azure.com/
AZURE_OPENAI_EMBEDDING_MODEL=text-embedding-ada-002

# Chat Service (Future Use)
AZURE_OPENAI_CHAT_KEY=2bgrZ8mkv9q0mENXaLLJM4FxFVczDAp1MSPLcGDRlRnmJkzyZSsTJQQJ99BEAC77bzfXJ3w3AAAAACOG774n
AZURE_OPENAI_CHAT_ENDPOINT=https://aura-india.cognitiveservices.azure.com/
AZURE_OPENAI_CHAT_MODEL=gpt-4.1-nano-AMC
``` -->
