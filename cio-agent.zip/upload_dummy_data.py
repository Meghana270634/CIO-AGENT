"""
Upload Dummy Data to Pinecone
This script uploads sample documents with embeddings to Pinecone for testing
"""

import os
import asyncio
import numpy as np
from dotenv import load_dotenv
from openai import AsyncAzureOpenAI
from pinecone import Pinecone

# Load environment variables
load_dotenv()

# Sample dummy documents
DUMMY_DOCUMENTS = [
    {
        "id": "doc1",
        "text": "Artificial Intelligence is transforming enterprise operations through automation and intelligent decision-making.",
        "metadata": {"category": "AI", "source": "tech_report", "year": 2024}
    },
    {
        "id": "doc2", 
        "text": "Cloud computing enables scalable infrastructure and reduces operational costs for businesses.",
        "metadata": {"category": "Cloud", "source": "whitepaper", "year": 2024}
    },
    {
        "id": "doc3",
        "text": "Data analytics helps organizations make informed decisions based on historical trends and patterns.",
        "metadata": {"category": "Analytics", "source": "research", "year": 2024}
    },
    {
        "id": "doc4",
        "text": "Cybersecurity is crucial for protecting sensitive business data and maintaining customer trust.",
        "metadata": {"category": "Security", "source": "security_guide", "year": 2024}
    },
    {
        "id": "doc5",
        "text": "Machine learning algorithms can predict customer behavior and optimize business processes.",
        "metadata": {"category": "ML", "source": "case_study", "year": 2024}
    }
]

async def get_embeddings(texts):
    """Generate embeddings using Azure OpenAI"""
    # Get Azure OpenAI credentials
    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
    
    # Initialize Azure OpenAI client
    client = AsyncAzureOpenAI(
        api_key=api_key,
        azure_endpoint=azure_endpoint,
        api_version=api_version
    )
    
    # Generate embeddings
    response = await client.embeddings.create(
        model="text-embedding-ada-002",
        input=texts
    )
    
    return [data.embedding for data in response.data]

def upload_to_pinecone():
    """Upload dummy data to Pinecone"""
    try:
        # Initialize Pinecone
        pc = Pinecone(api_key=os.getenv("PINECONE_API_KEY"))
        
        # Get or create index
        # index_name = "cio-agent-index"
        index_name = "membrane-poc-dotproduct"
        
        # Check if index exists
        if index_name not in pc.list_indexes().names():
            print(f"Creating index: {index_name}")
            pc.create_index(
                name=index_name,
                dimension=1536,  # text-embedding-ada-002 dimension
                metric="cosine",
                spec={
                    "serverless": {
                        "cloud": "aws",
                        "region": "us-east-1"
                    }
                }
            )
            print(f"Index {index_name} created successfully!")
        else:
            print(f"Index {index_name} already exists!")
        
        # Get index
        index = pc.Index(index_name)
        
        # Generate embeddings for all documents
        print("Generating embeddings...")
        texts = [doc["text"] for doc in DUMMY_DOCUMENTS]
        embeddings = asyncio.run(get_embeddings(texts))
        
        # Prepare vectors for upload
        vectors_to_upload = []
        for i, doc in enumerate(DUMMY_DOCUMENTS):
            vectors_to_upload.append({
                "id": doc["id"],
                "values": embeddings[i],
                "metadata": doc["metadata"]
            })
        
        # Upload vectors to Pinecone
        print("Uploading vectors to Pinecone...")
        index.upsert(vectors=vectors_to_upload)
        
        print(f"✅ Successfully uploaded {len(vectors_to_upload)} documents to Pinecone!")
        print(f"Index: {index_name}")
        print(f"Total vectors in index: {index.describe_index_stats().total_vector_count}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error uploading to Pinecone: {str(e)}")
        return False

if __name__ == "__main__":
    print("🚀 Starting Pinecone Dummy Data Upload...")
    
    # Check if Pinecone API key is set
    if not os.getenv("PINECONE_API_KEY"):
        print("❌ PINECONE_API_KEY not found in .env file!")
        print("Please add your Pinecone API key to .env file:")
        print("PINECONE_API_KEY=your_pinecone_api_key_here")
        exit(1)
    
    # Upload data
    success = upload_to_pinecone()
    
    if success:
        print("\n🎉 Dummy data upload completed successfully!")
        print("You can now test your VectorDB retrieval node!")
    else:
        print("\n💥 Upload failed. Please check your credentials and try again.")
